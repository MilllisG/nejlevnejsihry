import { NextRequest, NextResponse } from "next/server";
import Stripe from "stripe";
import { siteConfig } from "@/lib/config";
import { getProductBySlug, getSalePrice } from "@/lib/products";
import { toStripeAmountCzk } from "@/lib/pricing";

export const runtime = "nodejs";

type CheckoutBody = {
  slug?: string;
  lang?: "cs" | "en";
};

export async function POST(req: NextRequest) {
  const body = (await req.json().catch(() => ({}))) as CheckoutBody;
  const product = body.slug ? getProductBySlug(body.slug) : null;
  const lang = body.lang === "en" ? "en" : "cs";

  if (!product) {
    return NextResponse.json({ error: "Produkt nebyl nalezen." }, { status: 404 });
  }

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || req.nextUrl.origin || siteConfig.url;
  const mockMode = process.env.STRIPE_MOCK_MODE !== "false" || !process.env.STRIPE_SECRET_KEY;

  if (mockMode) {
    const demoUrl = new URL("/order/demo", siteUrl);
    demoUrl.searchParams.set("game", product.slug);
    demoUrl.searchParams.set("lang", lang);
    return NextResponse.json({ url: demoUrl.toString(), mode: "mock" });
  }

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string);
  const price = getSalePrice(product);

  const session = await stripe.checkout.sessions.create({
    mode: "payment",
    customer_creation: "if_required",
    billing_address_collection: "auto",
    line_items: [
      {
        quantity: 1,
        price_data: {
          currency: "czk",
          unit_amount: toStripeAmountCzk(price),
          product_data: {
            name: `${product.title} ${product.edition}`,
            description: `${product.platform} key • ${product.region} region`
          }
        }
      }
    ],
    metadata: {
      productSlug: product.slug,
      providerProductId: product.providerProductId,
      lang
    },
    success_url: `${siteUrl}/order/demo?paid=1&game=${encodeURIComponent(product.slug)}&lang=${lang}`,
    cancel_url: `${siteUrl}/games/${product.slug}?lang=${lang}&cancelled=1`
  });

  return NextResponse.json({ url: session.url });
}
