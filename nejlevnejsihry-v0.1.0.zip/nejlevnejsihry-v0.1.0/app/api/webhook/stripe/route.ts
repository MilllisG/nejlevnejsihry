import { NextResponse } from "next/server";
import Stripe from "stripe";
import { purchaseGameKey } from "@/lib/kinguin";
import { saveOrder } from "@/lib/orders";
import { getProductBySlug } from "@/lib/products";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const secretKey = process.env.STRIPE_SECRET_KEY;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!secretKey || !webhookSecret) {
    return NextResponse.json(
      { error: "Stripe webhook není nakonfigurovaný. Doplň STRIPE_SECRET_KEY a STRIPE_WEBHOOK_SECRET." },
      { status: 503 }
    );
  }

  const rawBody = await req.text();
  const signature = req.headers.get("stripe-signature");

  if (!signature) {
    return NextResponse.json({ error: "Chybí Stripe podpis." }, { status: 400 });
  }

  const stripe = new Stripe(secretKey);
  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Neplatný webhook podpis.";
    return NextResponse.json({ error: message }, { status: 400 });
  }

  if (event.type !== "checkout.session.completed") {
    return NextResponse.json({ received: true });
  }

  const session = event.data.object as Stripe.Checkout.Session;
  const productSlug = session.metadata?.productSlug;
  const product = productSlug ? getProductBySlug(productSlug) : null;

  if (!product) {
    await saveOrder({
      orderId: session.id,
      email: session.customer_details?.email,
      productSlug: productSlug || "unknown",
      providerProductId: "unknown",
      status: "failed",
      error: "Unknown productSlug in Stripe metadata."
    });

    return NextResponse.json({ error: "Neznámý produkt v metadatech." }, { status: 400 });
  }

  const purchase = await purchaseGameKey({
    providerProductId: product.providerProductId,
    orderId: session.id,
    email: session.customer_details?.email
  });

  await saveOrder({
    orderId: session.id,
    email: session.customer_details?.email,
    productSlug: product.slug,
    providerProductId: product.providerProductId,
    status: purchase.ok ? "completed" : "pending_manual_review",
    providerOrderId: purchase.providerOrderId,
    gameKey: purchase.key,
    error: purchase.error
  });

  if (!purchase.ok) {
    return NextResponse.json({ error: purchase.error || "Distributor selhal." }, { status: 502 });
  }

  // Do not return the key in webhook response. Deliver it by email/customer area after DB is connected.
  return NextResponse.json({ success: true, mode: purchase.mode });
}
