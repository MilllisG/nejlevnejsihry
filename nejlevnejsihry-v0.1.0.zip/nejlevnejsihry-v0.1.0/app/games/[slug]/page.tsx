import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { BuyButton } from "@/components/BuyButton";
import { normalizeLocale, siteConfig } from "@/lib/config";
import { formatCzk } from "@/lib/pricing";
import { getProductBySlug, getSalePrice, products } from "@/lib/products";

type PageProps = {
  params: Promise<{ slug: string }>;
  searchParams?: Promise<{ lang?: string }>;
};

export function generateStaticParams() {
  return products.map((product) => ({ slug: product.slug }));
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const product = getProductBySlug(slug);

  if (!product) {
    return { title: "Hra nenalezena" };
  }

  return {
    title: `${product.title} ${product.edition}`,
    description: product.descriptionCs,
    alternates: {
      canonical: `${siteConfig.url}/games/${product.slug}`
    },
    openGraph: {
      title: `${product.title} | ${siteConfig.name}`,
      description: product.descriptionCs,
      url: `${siteConfig.url}/games/${product.slug}`,
      type: "website"
    }
  };
}

export default async function GameDetail({ params, searchParams }: PageProps) {
  const { slug } = await params;
  const query = await searchParams;
  const lang = normalizeLocale(query?.lang);
  const product = getProductBySlug(slug);

  if (!product) notFound();

  const price = getSalePrice(product);
  const description = lang === "en" ? product.descriptionEn : product.descriptionCs;

  const productJsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: `${product.title} ${product.edition}`,
    description,
    brand: product.platform,
    sku: product.providerProductId,
    category: product.genre,
    aggregateRating: {
      "@type": "AggregateRating",
      ratingValue: product.rating,
      reviewCount: 42
    },
    offers: {
      "@type": "Offer",
      url: `${siteConfig.url}/games/${product.slug}`,
      priceCurrency: "CZK",
      price,
      availability: "https://schema.org/InStock",
      itemCondition: "https://schema.org/NewCondition",
      seller: {
        "@type": "Organization",
        name: siteConfig.name
      }
    }
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(productJsonLd) }} />
      <div className="container product-layout">
        <div className={`product-cover accent-${product.accent}`}>
          <span className="cover-badge">{product.badge}</span>
          <span className="product-title-cover">{product.title}</span>
          <span>{product.platform} • {product.region}</span>
        </div>

        <article className="product-info">
          <span className="eyebrow">{product.genre} • {product.region} region</span>
          <h1>{product.title}</h1>
          <p className="lead">{description}</p>

          <div className="info-table">
            <div className="info-cell"><span>Edice</span><strong>{product.edition}</strong></div>
            <div className="info-cell"><span>Platforma</span><strong>{product.platform}</strong></div>
            <div className="info-cell"><span>Region</span><strong>{product.region}</strong></div>
            <div className="info-cell"><span>Hodnocení</span><strong>★ {product.rating}/5</strong></div>
          </div>

          <div className="product-cta">
            <div>
              <span className="small-note">Cena s 5% marží</span>
              <span className="price">{formatCzk(price)}</span>
            </div>
            <BuyButton slug={product.slug} lang={lang} />
          </div>

          <div className="legal-card" style={{ marginTop: 18 }}>
            <h3>{lang === "en" ? "Important" : "Důležité"}</h3>
            <p>
              {lang === "en"
                ? "This is a starter build with demo products. Add real distributor IDs and legal documents before selling live keys."
                : "Toto je startovací build s demo produkty. Před ostrým prodejem doplň reálná ID distributora a finální právní dokumenty."}
            </p>
          </div>
        </article>
      </div>
    </>
  );
}
