import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container legal-page">
      <span className="eyebrow">404</span>
      <h1>Stránka nenalezena</h1>
      <p>Tohle není správný klíč. Vrať se zpět do katalogu her.</p>
      <Link className="btn btn-primary" href="/">Zpět na hlavní stránku</Link>
    </div>
  );
}
