import { siteConfig } from "@/lib/config";

export const metadata = { title: "Obchodní podmínky" };

export default function TermsPage() {
  return (
    <div className="container legal-page">
      <span className="eyebrow">Právní dokument</span>
      <h1>Obchodní podmínky</h1>
      <p className="warning">
        Toto je technická šablona pro start projektu, ne finální právní dokument. Před ostrým prodejem digitálních klíčů si nech text zkontrolovat právníkem.
      </p>
      <div className="legal-card">
        <h3>1. Provozovatel</h3>
        <p>Provozovatelem webu je {siteConfig.legalName}. Doplň IČO, sídlo, kontaktní e-mail a další povinné údaje před spuštěním ostrého prodeje.</p>
        <h3>2. Digitální obsah</h3>
        <p>Produktem jsou digitální herní klíče nebo přístupové kódy. Zákazník musí být před nákupem jasně informován o platformě, regionálním omezení a kompatibilitě produktu.</p>
        <h3>3. Doručení</h3>
        <p>Po úspěšné platbě systém připraví doručení digitálního klíče. Ostré doručení musí být řešené bezpečně, ideálně e-mailem nebo v zákaznické sekci.</p>
        <h3>4. Vrácení a reklamace</h3>
        <p>U digitálního obsahu je nutné správně nastavit souhlas se zahájením plnění a poučení o právu na odstoupení. Tohle si ověř podle aktuální české legislativy.</p>
      </div>
    </div>
  );
}
