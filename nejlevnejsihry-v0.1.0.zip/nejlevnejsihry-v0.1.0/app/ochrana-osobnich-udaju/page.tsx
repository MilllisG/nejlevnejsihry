import { siteConfig } from "@/lib/config";

export const metadata = { title: "Ochrana osobních údajů" };

export default function PrivacyPage() {
  return (
    <div className="container legal-page">
      <span className="eyebrow">GDPR</span>
      <h1>Ochrana osobních údajů</h1>
      <p className="warning">Toto je šablona. Před ostrým spuštěním doplň konkrétní zpracovatele, retenční lhůty a právní základy.</p>
      <div className="legal-card">
        <h3>Jaká data může web zpracovávat</h3>
        <ul>
          <li>E-mail zákazníka pro doručení digitálního produktu.</li>
          <li>Platební údaje zpracované platební bránou Stripe.</li>
          <li>Technické logy pro bezpečnost, audit objednávek a řešení reklamací.</li>
        </ul>
        <h3>Kontakt</h3>
        <p>Kontakt pro ochranu osobních údajů: {siteConfig.supportEmail}</p>
      </div>
    </div>
  );
}
