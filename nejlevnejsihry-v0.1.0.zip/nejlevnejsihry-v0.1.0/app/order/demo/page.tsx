import Link from "next/link";
import { normalizeLocale } from "@/lib/config";
import { getProductBySlug } from "@/lib/products";

type PageProps = {
  searchParams?: Promise<{ game?: string; paid?: string; lang?: string }>;
};

export default async function DemoOrderPage({ searchParams }: PageProps) {
  const params = await searchParams;
  const lang = normalizeLocale(params?.lang);
  const product = params?.game ? getProductBySlug(params.game) : null;
  const isPaidDemo = params?.paid === "1";

  return (
    <div className="container legal-page">
      <span className="eyebrow">{isPaidDemo ? "Stripe success" : "Demo checkout"}</span>
      <h1>{lang === "en" ? "Order flow is ready" : "Objednávkový tok je připravený"}</h1>
      <p>
        {lang === "en"
          ? "The site is currently in mock mode. After adding Stripe and distributor API keys, this page can be replaced by real order detail and key delivery."
          : "Web je teď v mock režimu. Po doplnění Stripe a distributor API klíčů se tahle stránka může nahradit reálným detailem objednávky a doručením klíče."}
      </p>
      {product ? (
        <div className="legal-card">
          <h3>{product.title}</h3>
          <p>{lang === "en" ? product.descriptionEn : product.descriptionCs}</p>
          <p className="warning">
            {lang === "en"
              ? "Demo key is not a real product key. Never show real keys on a public success page without authentication."
              : "Demo klíč není skutečný produktový klíč. Reálné klíče nikdy nezobrazuj na veřejné success stránce bez přihlášení/ověření."}
          </p>
          <p><strong>DEMO-KEY-AAAA-BBBB-CCCC</strong></p>
        </div>
      ) : null}
      <div className="hero-actions">
        <Link className="btn btn-primary" href={`/?lang=${lang}`}>{lang === "en" ? "Back to catalog" : "Zpět do katalogu"}</Link>
        {product ? <Link className="btn btn-secondary" href={`/games/${product.slug}?lang=${lang}`}>{lang === "en" ? "Product detail" : "Detail hry"}</Link> : null}
      </div>
    </div>
  );
}
