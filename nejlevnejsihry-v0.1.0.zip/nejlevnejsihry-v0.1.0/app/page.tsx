import Link from "next/link";
import { GameCard } from "@/components/GameCard";
import { normalizeLocale, siteConfig } from "@/lib/config";
import { getFeaturedProducts } from "@/lib/products";

type PageProps = {
  searchParams?: Promise<{ lang?: string }>;
};

const copy = {
  cs: {
    eyebrow: "PC herní klíče • demo připravené pro Stripe",
    titleA: "Levné PC hry.",
    titleB: "Okamžité doručení.",
    lead:
      "Hotový startovací e-shop pro nejlevnejsihry.link. Katalog běží hned, checkout je připravený na Stripe a distributor režim je bezpečně v mock módu, dokud nedoplníš reálné API klíče.",
    browse: "Prohlédnout katalog",
    discord: "Přijít na Discord",
    catalogTitle: "Katalog her",
    catalogDesc: "Ceny jsou počítané jako nákupní cena + 5% marže. Produktová data jsou teď demo, aby šel web bezpečně nasadit bez tajných klíčů.",
    langCs: "CZ",
    langEn: "EN",
    statsTitle: "Připraveno na produkční tok",
    stats: [
      ["Netlify", "next build + .next"],
      ["Stripe", "Checkout route připravena"],
      ["Kinguin/API", "mock/live přepínač"],
      ["SEO", "Product JSON-LD"]
    ],
    trustTitle: "Co už je v ZIPu hotové",
    trust: [
      ["Temný Guru design", "Responzivní homepage, karty her, detail produktu a právní stránky."],
      ["Bezpečný checkout základ", "Stripe se spustí až po doplnění klíčů. Bez nich web používá demo přesměrování."],
      ["Připraveno na API distributora", "Kinguin/distributor klient má mock i live režim a neukládá žádné tajné hodnoty do repozitáře."]
    ]
  },
  en: {
    eyebrow: "PC game keys • Stripe-ready demo",
    titleA: "Cheap PC games.",
    titleB: "Instant delivery.",
    lead:
      "A ready starter shop for nejlevnejsihry.link. The catalog runs immediately, checkout is prepared for Stripe and the distributor mode stays safely mocked until real API keys are added.",
    browse: "Browse catalog",
    discord: "Join Discord",
    catalogTitle: "Game catalog",
    catalogDesc: "Prices are calculated as source price + 5% margin. Product data is demo-only so the website can be safely deployed without secrets.",
    langCs: "CZ",
    langEn: "EN",
    statsTitle: "Production flow ready",
    stats: [
      ["Netlify", "next build + .next"],
      ["Stripe", "Checkout route ready"],
      ["Kinguin/API", "mock/live switch"],
      ["SEO", "Product JSON-LD"]
    ],
    trustTitle: "What is already included",
    trust: [
      ["Dark Guru design", "Responsive homepage, game cards, product detail and legal pages."],
      ["Safe checkout base", "Stripe activates only after adding keys. Without them, the site uses demo redirect."],
      ["Distributor API ready", "The Kinguin/distributor client has mock and live modes and keeps secrets out of the repo."]
    ]
  }
};

export default async function Home({ searchParams }: PageProps) {
  const params = await searchParams;
  const lang = normalizeLocale(params?.lang);
  const t = copy[lang];
  const products = getFeaturedProducts();

  const organizationJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: siteConfig.name,
    url: siteConfig.url,
    sameAs: [siteConfig.youtubeUrl, siteConfig.kickUrl, siteConfig.discordUrl]
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationJsonLd) }} />
      <section className="hero">
        <div className="container hero-grid">
          <div>
            <span className="eyebrow">{t.eyebrow}</span>
            <h1>
              {t.titleA}<br />
              <span className="gradient-text">{t.titleB}</span>
            </h1>
            <p className="lead">{t.lead}</p>
            <div className="hero-actions">
              <Link className="btn btn-primary" href="#katalog">{t.browse}</Link>
              <a className="btn btn-secondary" href={siteConfig.discordUrl} target="_blank" rel="noreferrer">{t.discord}</a>
            </div>
          </div>
          <aside className="stats-panel">
            <h2>{t.statsTitle}</h2>
            <div className="stat-list">
              {t.stats.map(([label, value]) => (
                <div className="stat-item" key={label}>
                  <strong>{label}</strong>
                  <span>{value}</span>
                </div>
              ))}
            </div>
          </aside>
        </div>
      </section>

      <section className="section" id="katalog">
        <div className="container">
          <div className="section-head">
            <div>
              <h2>{t.catalogTitle}</h2>
              <p className="section-desc">{t.catalogDesc}</p>
            </div>
            <div className="lang-switch" aria-label="Language switch">
              <Link className={lang === "cs" ? "active" : ""} href="/?lang=cs">{t.langCs}</Link>
              <Link className={lang === "en" ? "active" : ""} href="/?lang=en">{t.langEn}</Link>
            </div>
          </div>
          <div className="catalog-grid">
            {products.map((product) => (
              <GameCard key={product.slug} product={product} lang={lang} />
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head">
            <h2>{t.trustTitle}</h2>
          </div>
          <div className="trust-grid">
            {t.trust.map(([title, text]) => (
              <article className="trust-card" key={title}>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
