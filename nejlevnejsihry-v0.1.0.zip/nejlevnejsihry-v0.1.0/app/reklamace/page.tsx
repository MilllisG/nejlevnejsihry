import { siteConfig } from "@/lib/config";

export const metadata = { title: "Reklamace" };

export default function ComplaintsPage() {
  return (
    <div className="container legal-page">
      <span className="eyebrow">Podpora</span>
      <h1>Reklamace a podpora</h1>
      <div className="legal-card">
        <h3>Když klíč nefunguje</h3>
        <p>Zákazník by měl poslat e-mail na {siteConfig.supportEmail} s číslem objednávky, platformou a screenshotem chyby z aktivace.</p>
        <h3>Co bude potřeba doplnit před ostrým prodejem</h3>
        <ul>
          <li>Reálný helpdesk e-mail.</li>
          <li>Proces ověření aktivace klíče.</li>
          <li>Pravidla pro region-lock a špatně zakoupenou platformu.</li>
        </ul>
      </div>
    </div>
  );
}
