import type { MetadataRoute } from "next";
import { siteConfig } from "@/lib/config";
import { products } from "@/lib/products";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = siteConfig.url;
  const now = new Date();

  return [
    { url: base, lastModified: now, changeFrequency: "daily", priority: 1 },
    { url: `${base}/obchodni-podminky`, lastModified: now, changeFrequency: "monthly", priority: 0.5 },
    { url: `${base}/ochrana-osobnich-udaju`, lastModified: now, changeFrequency: "monthly", priority: 0.5 },
    { url: `${base}/reklamace`, lastModified: now, changeFrequency: "monthly", priority: 0.5 },
    ...products.map((product) => ({
      url: `${base}/games/${product.slug}`,
      lastModified: now,
      changeFrequency: "weekly" as const,
      priority: 0.8
    }))
  ];
}
