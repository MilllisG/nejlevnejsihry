"use client";

import { useState } from "react";

export function BuyButton({ slug, lang = "cs" }: { slug: string; lang?: "cs" | "en" }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleBuy() {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug, lang })
      });

      const data = (await response.json()) as { url?: string; error?: string };

      if (!response.ok || !data.url) {
        throw new Error(data.error || "Checkout se nepodařilo vytvořit.");
      }

      window.location.href = data.url;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Neznámá chyba checkoutu.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="buy-wrap">
      <button className="btn btn-primary" onClick={handleBuy} disabled={loading}>
        {loading ? "Připravuji…" : lang === "en" ? "Buy key" : "Koupit klíč"}
      </button>
      {error ? <p className="inline-error">{error}</p> : null}
    </div>
  );
}
