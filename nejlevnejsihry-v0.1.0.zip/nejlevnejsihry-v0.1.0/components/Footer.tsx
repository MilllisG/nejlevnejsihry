import Link from "next/link";
import { siteConfig } from "@/lib/config";

export function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <strong>{siteConfig.name}</strong>
          <p>Temný herní katalog připravený pro Stripe, distributora a Netlify nasazení.</p>
        </div>
        <div className="footer-links">
          <Link href="/obchodni-podminky">Obchodní podmínky</Link>
          <Link href="/ochrana-osobnich-udaju">Ochrana osobních údajů</Link>
          <Link href="/reklamace">Reklamace</Link>
        </div>
      </div>
    </footer>
  );
}
