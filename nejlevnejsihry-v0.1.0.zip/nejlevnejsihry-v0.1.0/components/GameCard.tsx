import Link from "next/link";
import { BuyButton } from "@/components/BuyButton";
import type { GameProduct } from "@/lib/products";
import { getSalePrice } from "@/lib/products";
import { formatCzk } from "@/lib/pricing";

export function GameCard({ product, lang }: { product: GameProduct; lang: "cs" | "en" }) {
  const salePrice = getSalePrice(product);
  const description = lang === "en" ? product.descriptionEn : product.descriptionCs;

  return (
    <article className={`game-card accent-${product.accent}`}>
      <Link href={`/games/${product.slug}?lang=${lang}`} className="cover" aria-label={product.title}>
        <span className="cover-badge">{product.badge}</span>
        <span className="cover-title">{product.title}</span>
      </Link>
      <div className="card-body">
        <div className="meta-row">
          <span>{product.platform}</span>
          <span>{product.region}</span>
          <span>★ {product.rating}</span>
        </div>
        <h3><Link href={`/games/${product.slug}?lang=${lang}`}>{product.title}</Link></h3>
        <p>{description}</p>
        <div className="price-row">
          <div>
            <span className="price">{formatCzk(salePrice)}</span>
            <span className="small-note">včetně 5% marže</span>
          </div>
          <BuyButton slug={product.slug} lang={lang} />
        </div>
      </div>
    </article>
  );
}
