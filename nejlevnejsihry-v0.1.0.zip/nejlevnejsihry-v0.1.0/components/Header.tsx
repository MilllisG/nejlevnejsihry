import Link from "next/link";
import { siteConfig } from "@/lib/config";

export function Header() {
  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link className="brand" href="/" aria-label="NejlevnejsiHry.link home">
          <span className="brand-mark">NH</span>
          <span>NejlevnejsiHry.link</span>
        </Link>
        <nav className="nav" aria-label="Hlavní navigace">
          <Link href="/#katalog">Katalog</Link>
          <Link href="/obchodni-podminky">Podmínky</Link>
          <a href={siteConfig.discordUrl} target="_blank" rel="noreferrer">Discord</a>
          <a href={siteConfig.youtubeUrl} target="_blank" rel="noreferrer">YouTube</a>
          <a href={siteConfig.kickUrl} target="_blank" rel="noreferrer">Kick</a>
        </nav>
      </div>
    </header>
  );
}
