export const siteConfig = {
  name: "NejlevnejsiHry.link",
  legalName: "NejlevnejsiHry.link",
  domain: "nejlevnejsihry.link",
  url: process.env.NEXT_PUBLIC_SITE_URL || "https://nejlevnejsihry.link",
  description:
    "Digitální PC herní klíče, rychlé doručení, temný herní katalog a napojení připravené pro Stripe a distributora.",
  discordUrl: process.env.NEXT_PUBLIC_DISCORD_URL || "https://discord.com/invite/n7xThr8",
  youtubeUrl: process.env.NEXT_PUBLIC_YOUTUBE_URL || "https://www.youtube.com/@TheHardwareGuru_Czech",
  kickUrl: process.env.NEXT_PUBLIC_KICK_URL || "https://kick.com/thehardwareguru",
  supportEmail: "podpora@nejlevnejsihry.link"
};

export const defaultLocale = "cs" as const;
export const locales = ["cs", "en"] as const;
export type Locale = (typeof locales)[number];

export function normalizeLocale(input?: string | null): Locale {
  return input === "en" ? "en" : "cs";
}
