export type PurchaseInput = {
  providerProductId: string;
  orderId: string;
  email?: string | null;
};

export type PurchaseResult = {
  ok: boolean;
  key?: string;
  providerOrderId?: string;
  mode: "mock" | "live";
  error?: string;
};

export async function purchaseGameKey(input: PurchaseInput): Promise<PurchaseResult> {
  const mode = process.env.KINGUIN_MODE === "live" ? "live" : "mock";

  if (mode === "mock") {
    return {
      ok: true,
      key: `DEMO-${input.providerProductId.toUpperCase().slice(0, 8)}-${Date.now().toString().slice(-6)}`,
      providerOrderId: `mock-${input.orderId}`,
      mode
    };
  }

  const endpoint = process.env.KINGUIN_ORDER_ENDPOINT;
  const token = process.env.KINGUIN_API_TOKEN;

  if (!endpoint || !token) {
    return {
      ok: false,
      mode,
      error: "Missing KINGUIN_ORDER_ENDPOINT or KINGUIN_API_TOKEN."
    };
  }

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      productId: input.providerProductId,
      quantity: 1,
      customerEmail: input.email,
      externalOrderId: input.orderId
    })
  });

  if (!response.ok) {
    return {
      ok: false,
      mode,
      error: `Distributor API failed with HTTP ${response.status}.`
    };
  }

  const data = (await response.json()) as Record<string, unknown>;
  const key = String(data.key || data.code || data.gameKey || "");

  if (!key) {
    return {
      ok: false,
      mode,
      error: "Distributor response did not contain key/code/gameKey."
    };
  }

  return {
    ok: true,
    key,
    providerOrderId: String(data.orderId || data.id || input.orderId),
    mode
  };
}
