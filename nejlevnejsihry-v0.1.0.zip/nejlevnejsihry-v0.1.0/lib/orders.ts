export type OrderRecord = {
  orderId: string;
  email?: string | null;
  productSlug: string;
  providerProductId: string;
  status: "completed" | "failed" | "pending_manual_review";
  providerOrderId?: string;
  gameKey?: string;
  error?: string;
};

export async function saveOrder(record: OrderRecord) {
  // Ready for future Netlify Database/Postgres integration.
  // Do not persist game keys in source code or public files.
  // In production, replace this with an INSERT into a locked server-only table.
  console.info("[order-record]", {
    ...record,
    gameKey: record.gameKey ? "[REDACTED]" : undefined
  });

  return { ok: true };
}
