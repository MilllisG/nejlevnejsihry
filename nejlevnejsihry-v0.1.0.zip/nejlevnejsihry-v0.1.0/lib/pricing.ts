export function formatCzk(amount: number) {
  return new Intl.NumberFormat("cs-CZ", {
    style: "currency",
    currency: "CZK",
    maximumFractionDigits: 0
  }).format(amount);
}

export function withMargin(basePriceCzk: number, marginPercent = 5) {
  return Math.ceil(basePriceCzk * (1 + marginPercent / 100));
}

export function toStripeAmountCzk(priceCzk: number) {
  return Math.round(priceCzk * 100);
}
