import { withMargin } from "@/lib/pricing";

export type GameProduct = {
  slug: string;
  title: string;
  edition: string;
  platform: "Steam" | "Epic" | "GOG";
  region: "EU" | "Global";
  genre: string;
  basePriceCzk: number;
  rating: number;
  badge: string;
  descriptionCs: string;
  descriptionEn: string;
  providerProductId: string;
  accent: string;
};


export const products: GameProduct[] = [
  {
    slug: "dark-frontier-steam-key",
    title: "Dark Frontier",
    edition: "Standard Edition",
    platform: "Steam",
    region: "EU",
    genre: "Survival horror",
    basePriceCzk: 399,
    rating: 4.7,
    badge: "Horor tip",
    descriptionCs:
      "Temná survival hororovka pro diváky, kteří chtějí atmosféru, lekačky a pořádný večerní chill stream.",
    descriptionEn:
      "A dark survival horror pick for players who want atmosphere, scares and late-night gaming tension.",
    providerProductId: "demo-dark-frontier-eu",
    accent: "purple"
  },
  {
    slug: "racing-apex-steam-key",
    title: "Racing Apex",
    edition: "Deluxe Edition",
    platform: "Steam",
    region: "Global",
    genre: "Racing",
    basePriceCzk: 549,
    rating: 4.6,
    badge: "Rychlé doručení",
    descriptionCs:
      "Arkádové závody s rychlým tempem, vhodné pro testování FPS, volantů i chill kompetitivní stream.",
    descriptionEn:
      "Fast arcade racing suitable for FPS testing, wheels and relaxed competitive streams.",
    providerProductId: "demo-racing-apex-global",
    accent: "cyan"
  },
  {
    slug: "strategy-kingdoms-gog-key",
    title: "Strategy Kingdoms",
    edition: "Complete Edition",
    platform: "GOG",
    region: "EU",
    genre: "Strategy",
    basePriceCzk: 699,
    rating: 4.8,
    badge: "Complete",
    descriptionCs:
      "Strategie pro dlouhé večery, budování ekonomiky a pomalé taktické hraní bez stresu.",
    descriptionEn:
      "A strategy pick for long sessions, economy building and slower tactical gameplay.",
    providerProductId: "demo-strategy-kingdoms-eu",
    accent: "amber"
  },
  {
    slug: "coop-chaos-steam-key",
    title: "Co-op Chaos",
    edition: "Party Pack",
    platform: "Steam",
    region: "Global",
    genre: "Co-op",
    basePriceCzk: 299,
    rating: 4.5,
    badge: "Pro komunitu",
    descriptionCs:
      "Kooperativní blázinec pro Discord komunitu, společné večery a streamy s diváky.",
    descriptionEn:
      "A co-op chaos game for Discord communities, group nights and viewer streams.",
    providerProductId: "demo-coop-chaos-global",
    accent: "green"
  }
].map((product) => ({
  ...product,
  basePriceCzk: product.basePriceCzk
}));

export function getSalePrice(product: GameProduct) {
  return withMargin(product.basePriceCzk, 5);
}

export function getProductBySlug(slug: string) {
  return products.find((product) => product.slug === slug);
}

export function getFeaturedProducts() {
  return products;
}
